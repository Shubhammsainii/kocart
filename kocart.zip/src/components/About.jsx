import React from 'react';
export default class About extends React.Component{
    render(){
    return (
        <>
        <h1>Wecome to About us Page</h1>
        </>
    );
    }
}